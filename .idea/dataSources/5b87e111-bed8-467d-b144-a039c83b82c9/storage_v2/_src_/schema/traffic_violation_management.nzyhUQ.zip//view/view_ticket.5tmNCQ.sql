create definer = root@localhost view view_ticket as
select `traffic_violation_management`.`ticket`.`T_no`                   AS `T_no`,
       `traffic_violation_management`.`driver`.`D_name`                 AS `D_name`,
       `traffic_violation_management`.`driver`.`D_license_number`       AS `D_license_number`,
       `traffic_violation_management`.`driver`.`D_address`              AS `D_address`,
       `traffic_violation_management`.`driver`.`D_postcode`             AS `D_postcode`,
       `traffic_violation_management`.`driver`.`D_phone`                AS `D_phone`,
       `traffic_violation_management`.`car`.`C_number`                  AS `C_number`,
       `traffic_violation_management`.`car`.`C_model`                   AS `C_model`,
       `traffic_violation_management`.`car`.`C_manufacturer`            AS `C_manufacturer`,
       `traffic_violation_management`.`car`.`C_production_date`         AS `C_production_date`,
       `traffic_violation_management`.`ticket`.`T_date`                 AS `T_date`,
       `traffic_violation_management`.`ticket`.`T_time`                 AS `T_time`,
       `traffic_violation_management`.`ticket`.`T_location`             AS `T_location`,
       `traffic_violation_management`.`ticket`.`T_record`               AS `T_record`,
       `traffic_violation_management`.`ticket`.`T_punishment_warning`   AS `T_punishment_warning`,
       `traffic_violation_management`.`ticket`.`T_punishment_fine`      AS `T_punishment_fine`,
       `traffic_violation_management`.`ticket`.`T_punishment_deduction` AS `T_punishment_deduction`,
       `traffic_violation_management`.`policemen`.`P_name`              AS `P_name`,
       `traffic_violation_management`.`policemen`.`P_no`                AS `P_no`
from (((`traffic_violation_management`.`driver` join `traffic_violation_management`.`car` on ((
        `traffic_violation_management`.`driver`.`D_no` =
        `traffic_violation_management`.`car`.`D_no`))) join `traffic_violation_management`.`ticket` on ((
        (`traffic_violation_management`.`car`.`C_no` = `traffic_violation_management`.`ticket`.`C_no`) and
        (`traffic_violation_management`.`driver`.`D_no` = `traffic_violation_management`.`ticket`.`D_no`))))
         join `traffic_violation_management`.`policemen` on ((`traffic_violation_management`.`ticket`.`P_no` =
                                                              `traffic_violation_management`.`policemen`.`P_no`)));

